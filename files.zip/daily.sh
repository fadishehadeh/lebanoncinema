#!/bin/bash
# ============================================
# LebanonCinema.com Daily Cron Job
# Add to crontab: 0 6 * * * /path/to/cron/daily.sh
# Runs at 6am daily, scrapes 7 days of showtimes
# ============================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
LOG_FILE="$SCRIPT_DIR/logs/scraper_$(date +%Y%m%d).log"

mkdir -p "$SCRIPT_DIR/logs"

echo "==============================" >> "$LOG_FILE"
echo "Started: $(date)"               >> "$LOG_FILE"
echo "==============================" >> "$LOG_FILE"

# Scrape VOX (7 days)
echo "[VOX] Starting scrape..."       >> "$LOG_FILE"
php "$PROJECT_DIR/scraper/vox_scraper.php" 7 >> "$LOG_FILE" 2>&1

# TODO: add Grand, Empire scrapers here when built
# php "$PROJECT_DIR/scraper/grand_scraper.php" 7 >> "$LOG_FILE" 2>&1

echo "Finished: $(date)"              >> "$LOG_FILE"

# Keep only last 14 days of logs
find "$SCRIPT_DIR/logs" -name "scraper_*.log" -mtime +14 -delete
