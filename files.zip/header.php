<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($pageTitle ?? SITE_NAME) ?></title>
    <meta name="description" content="Lebanon cinema showtimes — VOX, Grand, Empire, CinemaCity and more. Find what's playing today.">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        :root {
            --bg:        #0d0d0d;
            --surface:   #161616;
            --surface2:  #1e1e1e;
            --border:    #2a2a2a;
            --text:      #f0f0f0;
            --muted:     #888;
            --accent:    #e63946;
            --accent2:   #f4a261;
        }

        * { box-sizing: border-box; }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'Segoe UI', system-ui, sans-serif;
            min-height: 100vh;
        }

        /* ── Navbar ── */
        .navbar {
            background: var(--surface) !important;
            border-bottom: 1px solid var(--border);
            padding: 0.75rem 1.5rem;
        }
        .navbar-brand {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--text) !important;
            letter-spacing: -0.02em;
        }
        .navbar-brand span { color: var(--accent); }
        .nav-link { color: var(--muted) !important; font-size: 0.9rem; }
        .nav-link:hover { color: var(--text) !important; }

        /* ── Date tabs ── */
        .date-tabs {
            display: flex;
            gap: 0.4rem;
            overflow-x: auto;
            padding-bottom: 0.25rem;
        }
        .date-tabs::-webkit-scrollbar { height: 3px; }
        .date-tabs::-webkit-scrollbar-thumb { background: var(--border); }

        .date-tab {
            padding: 0.4rem 1rem;
            border-radius: 20px;
            background: var(--surface);
            border: 1px solid var(--border);
            color: var(--muted);
            text-decoration: none;
            font-size: 0.85rem;
            white-space: nowrap;
            transition: all 0.15s;
        }
        .date-tab:hover { border-color: var(--accent); color: var(--text); }
        .date-tab.active {
            background: var(--accent);
            border-color: var(--accent);
            color: #fff;
            font-weight: 600;
        }

        /* ── Movie card ── */
        .movie-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 1.25rem;
            transition: border-color 0.15s;
        }
        .movie-card:hover { border-color: #444; }

        .movie-poster {
            width: 80px;
            flex-shrink: 0;
        }
        .movie-poster img {
            width: 80px;
            height: 120px;
            object-fit: cover;
            border-radius: 8px;
        }
        .poster-placeholder {
            width: 80px;
            height: 120px;
            background: var(--surface2);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: var(--muted);
            border: 1px solid var(--border);
        }

        .movie-title {
            font-size: 1.1rem;
            font-weight: 700;
        }
        .movie-title a {
            color: var(--text);
            text-decoration: none;
        }
        .movie-title a:hover { color: var(--accent); }

        .movie-meta { font-size: 0.82rem; }

        .badge-rating {
            background: var(--surface2);
            border: 1px solid var(--border);
            color: var(--muted);
            font-size: 0.72rem;
            padding: 0.2rem 0.5rem;
            border-radius: 4px;
            white-space: nowrap;
            margin-top: 3px;
        }

        /* ── Cinema row ── */
        .cinema-row {
            display: flex;
            align-items: flex-start;
            gap: 0.75rem;
            flex-wrap: wrap;
        }
        .cinema-name {
            display: flex;
            align-items: center;
            gap: 0.4rem;
            min-width: 200px;
            font-size: 0.85rem;
        }
        .cinema-name a {
            color: var(--text);
            text-decoration: none;
        }
        .cinema-name a:hover { color: var(--accent2); }

        .chain-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            flex-shrink: 0;
        }
        .format-badge {
            background: #2a2a2a;
            color: var(--accent2);
            font-size: 0.65rem;
            padding: 0.1rem 0.4rem;
            border-radius: 3px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .times-row {
            display: flex;
            flex-wrap: wrap;
            gap: 0.35rem;
        }
        .time-pill {
            padding: 0.25rem 0.65rem;
            background: var(--surface2);
            border: 1px solid var(--border);
            border-radius: 20px;
            font-size: 0.8rem;
            color: var(--text);
            text-decoration: none;
            transition: all 0.15s;
        }
        .time-pill:hover, .time-pill.bookable:hover {
            background: var(--accent);
            border-color: var(--accent);
            color: #fff;
        }

        /* ── No showtimes ── */
        .no-showtimes {
            text-align: center;
            padding: 4rem 1rem;
            color: var(--muted);
        }

        /* ── Footer ── */
        footer {
            border-top: 1px solid var(--border);
            padding: 2rem 1.5rem;
            text-align: center;
            color: var(--muted);
            font-size: 0.82rem;
            margin-top: 4rem;
        }
        footer a { color: var(--muted); }
        footer a:hover { color: var(--text); }

        /* ── Responsive ── */
        @media (max-width: 576px) {
            .movie-poster { width: 60px; }
            .movie-poster img, .poster-placeholder { width: 60px; height: 90px; }
            .cinema-row { flex-direction: column; gap: 0.4rem; }
            .cinema-name { min-width: unset; }
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="/">Lebanon<span>Cinema</span></a>
        <div class="navbar-nav ms-auto flex-row gap-3">
            <a class="nav-link" href="/">Today</a>
            <a class="nav-link" href="/movies">Movies</a>
            <a class="nav-link" href="/cinemas">Cinemas</a>
        </div>
    </div>
</nav>
