<?php
// ─── Database config — edit these ───
define('DB_HOST', 'localhost');
define('DB_NAME', 'lebanon_cinema');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');

// ─── TMDB API (free at themoviedb.org) ───
define('TMDB_API_KEY', 'your_tmdb_api_key');
define('TMDB_BASE_URL', 'https://api.themoviedb.org/3');
define('TMDB_IMG_BASE', 'https://image.tmdb.org/t/p/w500');

// ─── Site config ───
define('SITE_URL',  'https://www.lebanoncinema.com');
define('SITE_NAME', 'Lebanon Cinema');

function getDbConnection(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;

    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
    return $pdo;
}
