<?php
require_once __DIR__ . '/../config.php';

$db   = getDbConnection();
$date = $_GET['date'] ?? date('Y-m-d');

// Validate date
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    $date = date('Y-m-d');
}

// Build date tabs: today + next 6 days
$dates = [];
for ($i = 0; $i < 7; $i++) {
    $d = date('Y-m-d', strtotime("+$i days"));
    $dates[] = [
        'value' => $d,
        'label' => $i === 0 ? 'Today' : ($i === 1 ? 'Tomorrow' : date('D d', strtotime($d))),
    ];
}

// Fetch showtimes grouped by movie → cinemas
$stmt = $db->prepare("
    SELECT
        m.id        AS movie_id,
        m.title,
        m.slug      AS movie_slug,
        m.poster_url,
        m.duration_min,
        m.rating,
        m.genres,
        c.id        AS cinema_id,
        c.name      AS cinema_name,
        c.slug      AS cinema_slug,
        ch.name     AS chain_name,
        ch.slug     AS chain_slug,
        ch.color_hex,
        GROUP_CONCAT(s.show_time ORDER BY s.show_time SEPARATOR ',') AS times,
        s.format,
        s.booking_url
    FROM showtimes s
    JOIN movies  m  ON s.movie_id  = m.id
    JOIN cinemas c  ON s.cinema_id = c.id
    JOIN chains  ch ON c.chain_id  = ch.id
    WHERE s.show_date = ?
    GROUP BY m.id, c.id, s.format
    ORDER BY m.title, ch.name, c.name
");
$stmt->execute([$date]);
$rows = $stmt->fetchAll();

// Restructure: movies → cinemas → times
$movies = [];
foreach ($rows as $row) {
    $mid = $row['movie_id'];
    if (!isset($movies[$mid])) {
        $movies[$mid] = [
            'title'       => $row['title'],
            'slug'        => $row['movie_slug'],
            'poster_url'  => $row['poster_url'],
            'duration'    => $row['duration_min'] ? $row['duration_min'] . ' min' : '',
            'rating'      => $row['rating'],
            'genres'      => $row['genres'],
            'cinemas'     => [],
        ];
    }
    $movies[$mid]['cinemas'][] = [
        'name'        => $row['cinema_name'],
        'slug'        => $row['cinema_slug'],
        'chain'       => $row['chain_name'],
        'chain_slug'  => $row['chain_slug'],
        'color'       => $row['color_hex'],
        'times'       => explode(',', $row['times']),
        'format'      => $row['format'],
        'booking_url' => $row['booking_url'],
    ];
}

$pageTitle = 'What\'s On Today in Lebanese Cinemas — ' . SITE_NAME;
include __DIR__ . '/includes/header.php';
?>

<div class="container py-4">

    <!-- Date Tabs -->
    <div class="date-tabs mb-4">
        <?php foreach ($dates as $d): ?>
            <a href="?date=<?= $d['value'] ?>"
               class="date-tab <?= $d['value'] === $date ? 'active' : '' ?>">
                <?= htmlspecialchars($d['label']) ?>
            </a>
        <?php endforeach; ?>
    </div>

    <?php if (empty($movies)): ?>
        <div class="no-showtimes">
            <p>No showtimes found for <?= htmlspecialchars($date) ?>.</p>
            <p class="text-muted small">Showtimes are updated daily at 6am. Check back soon.</p>
        </div>
    <?php else: ?>

        <p class="text-muted mb-4"><?= count($movies) ?> movies showing on <?= date('l, F j', strtotime($date)) ?></p>

        <?php foreach ($movies as $movie): ?>
        <div class="movie-card mb-5">
            <div class="row g-0">

                <!-- Poster -->
                <div class="col-auto">
                    <div class="movie-poster">
                        <?php if ($movie['poster_url']): ?>
                            <img src="<?= htmlspecialchars($movie['poster_url']) ?>"
                                 alt="<?= htmlspecialchars($movie['title']) ?>"
                                 loading="lazy">
                        <?php else: ?>
                            <div class="poster-placeholder"><?= htmlspecialchars(substr($movie['title'], 0, 1)) ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Info + showtimes -->
                <div class="col ps-3">
                    <div class="d-flex align-items-start gap-2 mb-1">
                        <h2 class="movie-title mb-0">
                            <a href="/movies/<?= htmlspecialchars($movie['slug']) ?>">
                                <?= htmlspecialchars($movie['title']) ?>
                            </a>
                        </h2>
                        <?php if ($movie['rating']): ?>
                            <span class="badge-rating"><?= htmlspecialchars($movie['rating']) ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="movie-meta text-muted mb-3">
                        <?= htmlspecialchars($movie['duration']) ?>
                        <?php if ($movie['genres']): ?>
                            &nbsp;·&nbsp; <?= htmlspecialchars($movie['genres']) ?>
                        <?php endif; ?>
                    </div>

                    <!-- Showtimes per cinema -->
                    <?php foreach ($movie['cinemas'] as $cinema): ?>
                    <div class="cinema-row mb-2">
                        <div class="cinema-name">
                            <span class="chain-dot" style="background:<?= htmlspecialchars($cinema['color']) ?>"></span>
                            <a href="/cinemas/<?= htmlspecialchars($cinema['slug']) ?>">
                                <?= htmlspecialchars($cinema['name']) ?>
                            </a>
                            <?php if ($cinema['format'] && $cinema['format'] !== 'Standard'): ?>
                                <span class="format-badge"><?= htmlspecialchars($cinema['format']) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="times-row">
                            <?php foreach ($cinema['times'] as $time): ?>
                                <?php
                                $formatted = date('g:i a', strtotime($time));
                                $href = $cinema['booking_url'] ?: '#';
                                ?>
                                <a href="<?= htmlspecialchars($href) ?>"
                                   target="<?= $cinema['booking_url'] ? '_blank' : '' ?>"
                                   class="time-pill <?= $cinema['booking_url'] ? 'bookable' : '' ?>">
                                    <?= $formatted ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>

                </div>
            </div>
        </div>
        <?php endforeach; ?>

    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
