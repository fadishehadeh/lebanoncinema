const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');
const path = require('path');

const URLS = [
  'https://leb.grandcinemasme.com/',
  'https://lbn.voxcinemas.com/',
  'https://www.cinemacitybeirut.com/browsing/',
  'https://lbn.voxcinemas.com/movies/whatson'
];

let allMovies = [];

// Set a user agent to avoid blocking
const headers = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
};

async function scrapeSiteCheerio(url, cinemaName) {
  console.log(`\n📺 Scraping ${cinemaName}...`);
  
  try {
    const response = await axios.get(url, { 
      headers,
      timeout: 10000
    });
    
    const $ = cheerio.load(response.data);
    const results = [];
    
    // Try to find movie elements
    const movieSelectors = [
      '.movie-card',
      '.film-item',
      '.cinema-item',
      '.movie-item',
      'article',
      '[class*="movie"]',
      '[class*="film"]'
    ];
    
    for (const selector of movieSelectors) {
      $(selector).each((i, element) => {
        const title = 
          $(element).find('h2, h3, .title, [class*="title"]').text().trim() ||
          $(element).text().trim().split('\n')[0];
          
        const time = $(element).find('[class*="time"], .time, .showtime').text().trim();
        const location = $(element).find('[class*="location"], [class*="venue"], [class*="branch"]').text().trim();
        
        if (title && title.length > 2 && title.length < 200) {
          results.push({
            movie: title,
            date: new Date().toISOString().split('T')[0],
            time: time || 'Not specified',
            location: location || 'Not specified',
            cinema: cinemaName,
            url: url
          });
        }
      });
      
      if (results.length > 0) {
        allMovies.push(...results);
        console.log(`✓ Found ${results.length} movies`);
        break;
      }
    }
    
    if (results.length === 0) {
      console.log('⚠ No movies found with standard selectors');
    }
    
  } catch (error) {
    console.error(`✗ Error: ${error.message}`);
  }
}

async function runScraper() {
  console.log('🎬 Starting Cinema Scraper (Cheerio Version)...');
  console.log('═'.repeat(50));
  console.log('Sites to scrape:');
  URLS.forEach((url, i) => console.log(`  ${i + 1}. ${url}`));
  console.log('═'.repeat(50));
  
  try {
    await scrapeSiteCheerio(URLS[0], 'Grand Cinema');
    await scrapeSiteCheerio(URLS[1], 'Vox Cinemas');
    await scrapeSiteCheerio(URLS[3], 'Vox Cinemas (What\'s On)');
    await scrapeSiteCheerio(URLS[2], 'Cinema City');
    
    // Remove duplicates
    const uniqueMovies = Array.from(
      new Map(
        allMovies.map(movie => [
          `${movie.movie}|${movie.cinema}`,
          movie
        ])
      ).values()
    );
    
    // Sort by cinema, then movie
    uniqueMovies.sort((a, b) => {
      if (a.cinema !== b.cinema) return a.cinema.localeCompare(b.cinema);
      return a.movie.localeCompare(b.movie);
    });
    
    // Save to JSON
    const outputPath = path.join(process.cwd(), 'movies.json');
    fs.writeFileSync(
      outputPath,
      JSON.stringify({
        metadata: {
          scrapedAt: new Date().toISOString(),
          totalMovies: uniqueMovies.length,
          sources: URLS
        },
        movies: uniqueMovies
      }, null, 2)
    );
    
    console.log('\n' + '═'.repeat(50));
    console.log('✅ SCRAPING COMPLETE');
    console.log('═'.repeat(50));
    console.log(`📊 Total unique movies: ${uniqueMovies.length}`);
    console.log(`📁 Saved to: ${outputPath}`);
    
    console.log('\n📋 Summary by Cinema:');
    const summary = {};
    uniqueMovies.forEach(movie => {
      summary[movie.cinema] = (summary[movie.cinema] || 0) + 1;
    });
    
    Object.entries(summary).sort().forEach(([cinema, count]) => {
      console.log(`   • ${cinema}: ${count} movies`);
    });
    
    if (uniqueMovies.length > 0) {
      console.log('\n📋 Sample data (first 3 movies):');
      uniqueMovies.slice(0, 3).forEach(movie => {
        console.log(`   ${movie.movie} | ${movie.cinema} | ${movie.time}`);
      });
    }
    
  } catch (error) {
    console.error('Fatal error:', error);
    process.exit(1);
  }
}

runScraper();
