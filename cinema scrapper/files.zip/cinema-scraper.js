const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

const URLS = [
  'https://leb.grandcinemasme.com/',
  'https://lbn.voxcinemas.com/',
  'https://www.cinemacitybeirut.com/browsing/',
  'https://lbn.voxcinemas.com/movies/whatson'
];

let allMovies = [];

async function scrapeGrandCinema() {
  console.log('\n📺 Scraping Grand Cinema...');
  const browser = await puppeteer.launch({ headless: 'new' });
  const page = await browser.newPage();
  
  try {
    await page.goto('https://leb.grandcinemasme.com/', { 
      waitUntil: 'networkidle2', 
      timeout: 30000 
    });
    
    // Wait for content to load
    await page.waitForSelector('body', { timeout: 5000 }).catch(() => {});
    
    const movies = await page.evaluate(() => {
      const results = [];
      
      // Try multiple possible selectors for movies
      const selectors = [
        '.movie-card',
        '.film-item',
        '[class*="movie"]',
        '[class*="film"]',
        'article',
        '.item'
      ];
      
      for (const selector of selectors) {
        const elements = document.querySelectorAll(selector);
        if (elements.length > 0) {
          elements.forEach(el => {
            const title = 
              el.querySelector('h2, h3, .title, [class*="title"]')?.textContent?.trim() ||
              el.textContent?.trim().split('\n')[0];
              
            const time = el.querySelector('[class*="time"], .time, .showtime')?.textContent?.trim();
            const location = el.querySelector('[class*="location"], [class*="cinema"], .venue')?.textContent?.trim();
            
            if (title && title.length > 2 && title.length < 200) {
              results.push({
                movie: title,
                time: time || 'Not specified',
                location: location || 'Not specified',
                cinema: 'Grand Cinema',
                date: new Date().toISOString().split('T')[0],
                url: 'https://leb.grandcinemasme.com/'
              });
            }
          });
          if (results.length > 0) break;
        }
      }
      
      return results;
    });
    
    allMovies.push(...movies);
    console.log(`✓ Found ${movies.length} movies`);
    
  } catch (error) {
    console.error('Error scraping Grand Cinema:', error.message);
  } finally {
    await browser.close();
  }
}

async function scrapeVoxCinemas() {
  console.log('\n🎬 Scraping Vox Cinemas...');
  const browser = await puppeteer.launch({ headless: 'new' });
  const page = await browser.newPage();
  
  try {
    await page.goto('https://lbn.voxcinemas.com/', { 
      waitUntil: 'networkidle2', 
      timeout: 30000 
    });
    
    await page.waitForSelector('body', { timeout: 5000 }).catch(() => {});
    
    const movies = await page.evaluate(() => {
      const results = [];
      
      const selectors = [
        '.movie-card',
        '.featured-movie',
        '[class*="movie"]',
        'article',
        '.item'
      ];
      
      for (const selector of selectors) {
        const elements = document.querySelectorAll(selector);
        if (elements.length > 0) {
          elements.forEach(el => {
            const title = 
              el.querySelector('h2, h3, .title, [class*="name"]')?.textContent?.trim() ||
              el.textContent?.trim().split('\n')[0];
              
            const time = el.querySelector('[class*="time"], .showtime, .time')?.textContent?.trim();
            const location = el.querySelector('[class*="location"], [class*="venue"], .branch')?.textContent?.trim();
            
            if (title && title.length > 2 && title.length < 200) {
              results.push({
                movie: title,
                time: time || 'Not specified',
                location: location || 'Not specified',
                cinema: 'Vox Cinemas',
                date: new Date().toISOString().split('T')[0],
                url: 'https://lbn.voxcinemas.com/'
              });
            }
          });
          if (results.length > 0) break;
        }
      }
      
      return results;
    });
    
    allMovies.push(...movies);
    console.log(`✓ Found ${movies.length} movies`);
    
  } catch (error) {
    console.error('Error scraping Vox Cinemas:', error.message);
  } finally {
    await browser.close();
  }
}

async function scrapeVoxWhatson() {
  console.log('\n🎭 Scraping Vox Cinemas What\'s On...');
  const browser = await puppeteer.launch({ headless: 'new' });
  const page = await browser.newPage();
  
  try {
    await page.goto('https://lbn.voxcinemas.com/movies/whatson', { 
      waitUntil: 'networkidle2', 
      timeout: 30000 
    });
    
    await page.waitForSelector('body', { timeout: 5000 }).catch(() => {});
    
    const movies = await page.evaluate(() => {
      const results = [];
      
      const selectors = [
        '.movie-item',
        '.movie-card',
        '[class*="movie"]',
        'article',
        '.item'
      ];
      
      for (const selector of selectors) {
        const elements = document.querySelectorAll(selector);
        if (elements.length > 0) {
          elements.forEach(el => {
            const title = 
              el.querySelector('h2, h3, .title, [class*="name"]')?.textContent?.trim() ||
              el.textContent?.trim().split('\n')[0];
              
            const time = el.querySelector('[class*="time"], .showtime, .time, span')?.textContent?.trim();
            const location = el.querySelector('[class*="location"], [class*="venue"], .branch')?.textContent?.trim();
            
            if (title && title.length > 2 && title.length < 200) {
              results.push({
                movie: title,
                time: time || 'Not specified',
                location: location || 'Not specified',
                cinema: 'Vox Cinemas',
                date: new Date().toISOString().split('T')[0],
                url: 'https://lbn.voxcinemas.com/movies/whatson'
              });
            }
          });
          if (results.length > 0) break;
        }
      }
      
      return results;
    });
    
    allMovies.push(...movies);
    console.log(`✓ Found ${movies.length} movies`);
    
  } catch (error) {
    console.error('Error scraping Vox What\'s On:', error.message);
  } finally {
    await browser.close();
  }
}

async function scrapeCinemaCity() {
  console.log('\n🎪 Scraping Cinema City...');
  const browser = await puppeteer.launch({ headless: 'new' });
  const page = await browser.newPage();
  
  try {
    await page.goto('https://www.cinemacitybeirut.com/browsing/', { 
      waitUntil: 'networkidle2', 
      timeout: 30000 
    });
    
    await page.waitForSelector('body', { timeout: 5000 }).catch(() => {});
    
    const movies = await page.evaluate(() => {
      const results = [];
      
      const selectors = [
        '.cinema-item',
        '.movie-item',
        '.item',
        '[class*="movie"]',
        'article'
      ];
      
      for (const selector of selectors) {
        const elements = document.querySelectorAll(selector);
        if (elements.length > 0) {
          elements.forEach(el => {
            const title = 
              el.querySelector('h2, h3, .title, [class*="name"]')?.textContent?.trim() ||
              el.textContent?.trim().split('\n')[0];
              
            const time = el.querySelector('[class*="time"], .showtime, .time, span')?.textContent?.trim();
            const location = el.querySelector('[class*="location"], [class*="venue"], [class*="branch"]')?.textContent?.trim();
            
            if (title && title.length > 2 && title.length < 200) {
              results.push({
                movie: title,
                time: time || 'Not specified',
                location: location || 'Not specified',
                cinema: 'Cinema City',
                date: new Date().toISOString().split('T')[0],
                url: 'https://www.cinemacitybeirut.com/browsing/'
              });
            }
          });
          if (results.length > 0) break;
        }
      }
      
      return results;
    });
    
    allMovies.push(...movies);
    console.log(`✓ Found ${movies.length} movies`);
    
  } catch (error) {
    console.error('Error scraping Cinema City:', error.message);
  } finally {
    await browser.close();
  }
}

async function runScraper() {
  console.log('🎬 Starting Cinema Scraper...');
  console.log('═'.repeat(50));
  console.log('Sites to scrape:');
  URLS.forEach((url, i) => console.log(`  ${i + 1}. ${url}`));
  console.log('═'.repeat(50));
  
  try {
    await scrapeGrandCinema();
    await scrapeVoxCinemas();
    await scrapeVoxWhatson();
    await scrapeCinemaCity();
    
    // Remove duplicates based on movie title + cinema
    const uniqueMovies = Array.from(
      new Map(
        allMovies.map(movie => [
          `${movie.movie}|${movie.cinema}`,
          movie
        ])
      ).values()
    );
    
    // Sort by cinema, then movie name
    uniqueMovies.sort((a, b) => {
      if (a.cinema !== b.cinema) return a.cinema.localeCompare(b.cinema);
      return a.movie.localeCompare(b.movie);
    });
    
    // Save to JSON file in current directory
    const outputPath = path.join(process.cwd(), 'movies.json');
    fs.writeFileSync(
      outputPath,
      JSON.stringify({
        metadata: {
          scrapedAt: new Date().toISOString(),
          totalMovies: uniqueMovies.length,
          sources: URLS
        },
        movies: uniqueMovies
      }, null, 2)
    );
    
    console.log('\n' + '═'.repeat(50));
    console.log('✅ SCRAPING COMPLETE');
    console.log('═'.repeat(50));
    console.log(`📊 Total unique movies: ${uniqueMovies.length}`);
    console.log(`📁 Saved to: ${outputPath}`);
    
    console.log('\n📋 Summary by Cinema:');
    const summary = {};
    uniqueMovies.forEach(movie => {
      summary[movie.cinema] = (summary[movie.cinema] || 0) + 1;
    });
    
    Object.entries(summary).sort().forEach(([cinema, count]) => {
      console.log(`   • ${cinema}: ${count} movies`);
    });
    
    console.log('\n📋 Sample data (first 3 movies):');
    uniqueMovies.slice(0, 3).forEach(movie => {
      console.log(`   ${movie.movie} | ${movie.cinema} | ${movie.time}`);
    });
    
  } catch (error) {
    console.error('Fatal error:', error);
    process.exit(1);
  }
}

runScraper();
